<script src="{{ asset('assets/scripts/app.js') }}"></script>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="{{ asset('assets/datatables/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('frontend/js/bootstrap-tagsinput.min.js')}}"></script>
<script src="{{ asset('assets/select2/select2.min.js') }}"></script>
<script src="{{ asset('assets/scripts/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('assets/scripts/alert.js') }}"></script>
@stack('include-js')

<script src="{{ asset('assets/scripts/main.js') }}"></script>
<script>
    $(".input-tag").tagsinput('items');
</script>
